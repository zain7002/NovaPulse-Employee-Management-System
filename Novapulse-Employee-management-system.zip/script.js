const API_BASE = 'http://localhost:8080/api/employees';

// === GLOBAL STATE ===
let allEmployees = [];
let filteredEmployees = [];
let currentPage = 1;
const PAGE_SIZE = 10;
let editingId = null;
let chartInstances = {}; // store chart references for cleanup

// === INITIALIZATION ===
document.addEventListener('DOMContentLoaded', () => {
    loadTheme();
    setupSidebar();
    setupNotifications();

    const page = document.body.getAttribute('data-page');
    
    switch (page) {
        case 'dashboard':
            initDashboard();
            break;
        case 'employees':
            initEmployees();
            break;
        case 'departments':
            initDepartments();
            break;
        case 'salary':
            initSalary();
            break;
        case 'settings':
            initSettings();
            break;
        case 'login':
            initLogin();
            break;
    }

    if (typeof lucide !== 'undefined') lucide.createIcons();

    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
});

// === API LAYER ===

async function fetchEmployees() {
    try {
        const response = await fetch(API_BASE);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        throw new Error('Failed to fetch employees. Please check if the server is running.');
    }
}

async function fetchEmployeeById(id) {
    try {
        const response = await fetch(`${API_BASE}/${id}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        throw new Error(`Failed to fetch employee with ID ${id}`);
    }
}

async function createEmployee(data) {
    try {
        const response = await fetch(API_BASE, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        if (response.status === 409) {
            throw new Error('Email already exists in the system.');
        }
        
        if (!response.ok) {
            let errorMsg = 'Failed to create employee';
            const text = await response.text();
            if (text) {
                try {
                    const errData = JSON.parse(text);
                    errorMsg = errData.message || errData.error || text;
                } catch (e) {
                    errorMsg = text;
                }
            }
            throw new Error(errorMsg);
        }
        
        return await response.json();
    } catch (error) {
        if (error.name === 'TypeError' && error.message.includes('fetch')) {
            throw new Error('Cannot connect to Spring Boot backend at http://localhost:8080. Please make sure your backend is running and CORS is enabled.');
        }
        throw error;
    }
}

async function updateEmployee(id, data) {
    try {
        const response = await fetch(`${API_BASE}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        if (response.status === 409) {
            throw new Error('Email already exists in the system.');
        }
        
        if (!response.ok) {
            let errorMsg = 'Failed to update employee';
            const text = await response.text();
            if (text) {
                try {
                    const errData = JSON.parse(text);
                    errorMsg = errData.message || errData.error || text;
                } catch (e) {
                    errorMsg = text;
                }
            }
            throw new Error(errorMsg);
        }
        
        return await response.json();
    } catch (error) {
        if (error.name === 'TypeError' && error.message.includes('fetch')) {
            throw new Error('Cannot connect to Spring Boot backend at http://localhost:8080. Please make sure your backend is running and CORS is enabled.');
        }
        throw error;
    }
}

async function deleteEmployeeAPI(id) {
    try {
        const response = await fetch(`${API_BASE}/${id}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            const text = await response.text();
            throw new Error(text || 'Failed to delete employee');
        }
        
        return true;
    } catch (error) {
        if (error.name === 'TypeError' && error.message.includes('fetch')) {
            throw new Error('Cannot connect to Spring Boot backend at http://localhost:8080.');
        }
        throw error;
    }
}

// === LOGIN PAGE ===

function initLogin() {
    const loginForm = document.getElementById('loginForm');
    const loginEmail = document.getElementById('loginEmail');
    const loginPassword = document.getElementById('loginPassword');
    const loginAlert = document.getElementById('loginAlert');
    const togglePassword = document.getElementById('togglePassword');

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const email = loginEmail.value.trim();
            const password = loginPassword.value.trim();
            let isValid = true;
            
            // Clear previous errors
            document.querySelectorAll('.error-message').forEach(el => el.remove());
            loginEmail.classList.remove('error');
            loginPassword.classList.remove('error');
            
            if (!email) {
                isValid = false;
                showInlineError(loginEmail, 'Email is required');
            }
            if (!password) {
                isValid = false;
                showInlineError(loginPassword, 'Password is required');
            }
            
            if (!isValid) return;
            
            if (email === 'admin@company.com' && password === 'admin123') {
                sessionStorage.setItem('ems_logged_in', 'true');
                window.location.href = 'dashboard.html';
            } else {
                if (loginAlert) loginAlert.classList.add('show');
            }
        });
    }
    
    if (togglePassword) {
        togglePassword.addEventListener('click', () => {
            const type = loginPassword.getAttribute('type') === 'password' ? 'text' : 'password';
            loginPassword.setAttribute('type', type);
            // Toggle icon if needed
            const icon = togglePassword.querySelector('i');
            if (icon) {
                icon.setAttribute('data-lucide', type === 'password' ? 'eye' : 'eye-off');
                if (typeof lucide !== 'undefined') lucide.createIcons();
            }
        });
    }
}

function showInlineError(inputElement, message) {
    const errorEl = document.createElement('span');
    errorEl.className = 'error-message';
    errorEl.style.color = 'var(--danger, #ef4444)';
    errorEl.style.fontSize = '12px';
    errorEl.style.marginTop = '4px';
    errorEl.style.display = 'block';
    errorEl.textContent = message;
    inputElement.classList.add('error');
    inputElement.parentNode.appendChild(errorEl);
}

// === DASHBOARD ===

async function initDashboard() {
    const welcomeGreeting = document.getElementById('welcomeGreeting');
    if (welcomeGreeting) {
        welcomeGreeting.textContent = `${getGreeting()}, Admin 👋`;
    }
    
    try {
        allEmployees = await fetchEmployees();
        renderDashboardKPIs(allEmployees);
        renderDashboardCharts(allEmployees);
        renderRecentEmployees(allEmployees);
    } catch (error) {
        showToast(error.message || 'Cannot connect to Spring Boot backend.', 'error');
        renderDashboardKPIs([]);
        renderRecentEmployees([]);
    }
}

function renderDashboardKPIs(employees) {
    const kpiTotalEmployees = document.getElementById('kpiTotalEmployees');
    const kpiTotalDepartments = document.getElementById('kpiTotalDepartments');
    const kpiAvgSalary = document.getElementById('kpiAvgSalary');
    const kpiTotalPayroll = document.getElementById('kpiTotalPayroll');
    
    if (!kpiTotalEmployees) return; // Ensure elements exist

    const totalEmployees = employees.length;
    const uniqueDepartments = new Set(employees.map(e => e.department)).size;
    
    let totalPayroll = 0;
    employees.forEach(e => totalPayroll += e.salary);
    
    const avgSalary = totalEmployees > 0 ? totalPayroll / totalEmployees : 0;
    
    kpiTotalEmployees.textContent = totalEmployees;
    kpiTotalDepartments.textContent = uniqueDepartments;
    kpiAvgSalary.textContent = formatCurrency(avgSalary);
    kpiTotalPayroll.textContent = formatCurrency(totalPayroll);
}

function renderDashboardCharts(employees) {
    const deptChartCanvas = document.getElementById('deptChart');
    const salaryChartCanvas = document.getElementById('salaryChart');
    
    if (!deptChartCanvas || !salaryChartCanvas) return;
    
    // Destroy existing
    if (chartInstances.deptChart) chartInstances.deptChart.destroy();
    if (chartInstances.salaryChart) chartInstances.salaryChart.destroy();
    
    // Process Data for Dept Chart
    const deptCounts = {};
    const deptSalaries = {};
    
    employees.forEach(e => {
        const d = e.department || 'Unassigned';
        deptCounts[d] = (deptCounts[d] || 0) + 1;
        
        if (!deptSalaries[d]) {
            deptSalaries[d] = { total: 0, count: 0 };
        }
        deptSalaries[d].total += e.salary;
        deptSalaries[d].count += 1;
    });
    
    const deptLabels = Object.keys(deptCounts);
    const deptData = Object.values(deptCounts);
    
    // Render Department Headcount Progress Bars
    const deptProgressList = document.getElementById('deptProgressList');
    if (deptProgressList) {
        deptProgressList.innerHTML = '';
        if (deptLabels.length === 0) {
            deptProgressList.innerHTML = '<div class="text-muted text-center py-4">No department data available</div>';
        } else {
            const totalEmps = employees.length || 1;
            const palette = ['#6366f1', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#ec4899'];
            deptLabels.forEach((d, i) => {
                const count = deptCounts[d];
                const pct = Math.round((count / totalEmps) * 100);
                const color = palette[i % palette.length];
                
                const item = document.createElement('div');
                item.style.marginBottom = '14px';
                item.innerHTML = `
                    <div style="display:flex; justify-content:space-between; font-size:0.85rem; font-weight:600; margin-bottom:6px;">
                        <span style="color:var(--text);">${d}</span>
                        <span style="color:var(--text-secondary); font-size:0.8rem;">${count} employees (${pct}%)</span>
                    </div>
                    <div style="height:8px; width:100%; background:var(--bg); border-radius:4px; overflow:hidden;">
                        <div style="height:100%; width:${pct}%; background:${color}; border-radius:4px; transition:width 0.5s ease;"></div>
                    </div>
                `;
                deptProgressList.appendChild(item);
            });
        }
    }
    
    const colors = ['#3b82f6','#8b5cf6','#06b6d4','#10b981','#f59e0b','#ef4444','#ec4899','#6366f1'];
    
    chartInstances.deptChart = new Chart(deptChartCanvas, {
        type: 'doughnut',
        data: {
            labels: deptLabels,
            datasets: [{
                data: deptData,
                backgroundColor: colors,
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 16,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                }
            }
        }
    });
    
    // Process Data for Salary Chart
    const avgSalaries = deptLabels.map(d => deptSalaries[d].total / deptSalaries[d].count);
    
    chartInstances.salaryChart = new Chart(salaryChartCanvas, {
        type: 'bar',
        data: {
            labels: deptLabels,
            datasets: [{
                label: 'Avg Salary',
                data: avgSalaries,
                backgroundColor: 'rgba(59,130,246,0.7)',
                borderColor: '#3b82f6',
                borderWidth: 1,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: val => '$' + val.toLocaleString()
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

function renderRecentEmployees(employees) {
    const recentTableBody = document.getElementById('recentTableBody');
    if (!recentTableBody) return;
    
    recentTableBody.innerHTML = '';
    
    if (employees.length === 0) {
        recentTableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:20px;">No employees found</td></tr>';
        return;
    }
    
    const recent = employees.slice(-5).reverse();
    
    recent.forEach(emp => {
        const tr = document.createElement('tr');
        const color = getAvatarColor(emp.firstName + ' ' + emp.lastName);
        const initials = getInitials(emp.firstName, emp.lastName);
        
        tr.innerHTML = `
            <td>
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width:36px;height:36px;border-radius:50%;background:${color};color:white;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:14px;flex-shrink:0;">
                        ${initials}
                    </div>
                    <div>
                        <div style="font-weight: 600; color: var(--text); font-size: 0.88rem;">${emp.firstName} ${emp.lastName}</div>
                        <div style="font-size: 0.75rem; color: var(--primary); font-weight: 500;">${emp.position || 'Team Member'}</div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">${emp.email}</div>
                    </div>
                </div>
            </td>
            <td><span class="badge" style="background:var(--bg-secondary); border:1px solid var(--border); padding:4px 8px; border-radius:12px; font-size:12px;">${emp.department}</span></td>
            <td style="font-weight: 600;">${formatCurrency(emp.salary)}</td>
            <td>
                <a href="employees.html" class="btn btn-sm btn-outline" style="text-decoration:none; display:inline-block;">View</a>
            </td>
        `;
        recentTableBody.appendChild(tr);
    });
}


// === EMPLOYEES PAGE ===

async function initEmployees() {
    // Setup listeners
    const searchInput = document.getElementById('searchInput');
    const departmentFilter = document.getElementById('departmentFilter');
    const salarySort = document.getElementById('salarySort');
    const clearFiltersBtn = document.getElementById('clearFilters');
    const addEmployeeBtn = document.getElementById('addEmployeeBtn');
    const employeeForm = document.getElementById('employeeForm');
    
    if (searchInput) searchInput.addEventListener('input', debounce(applyFilters, 300));
    if (departmentFilter) departmentFilter.addEventListener('change', applyFilters);
    if (salarySort) salarySort.addEventListener('change', applyFilters);
    if (clearFiltersBtn) clearFiltersBtn.addEventListener('click', () => {
        if(searchInput) searchInput.value = '';
        if(departmentFilter) departmentFilter.value = '';
        if(salarySort) salarySort.value = '';
        applyFilters();
    });
    
    if (addEmployeeBtn) addEmployeeBtn.addEventListener('click', openAddModal);
    if (employeeForm) employeeForm.addEventListener('submit', handleSaveEmployee);
    
    // Setup Modal Close Buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if(modal) closeModal(modal.id);
        });
    });
    
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', function() {
            const modal = this.closest('.modal');
            if(modal) closeModal(modal.id);
        });
    });
    
    const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    if (confirmDeleteBtn) {
        confirmDeleteBtn.addEventListener('click', async () => {
            const btn = confirmDeleteBtn;
            btn.textContent = 'Deleting...';
            btn.disabled = true;
            try {
                await deleteEmployeeAPI(window._deleteId);
                showToast('Employee deleted successfully', 'success');
                closeModal('deleteModal');
                // Refresh data
                allEmployees = await fetchEmployees();
                applyFilters();
            } catch (err) {
                showToast('Failed to delete employee', 'error');
            } finally {
                btn.textContent = 'Delete Employee';
                btn.disabled = false;
            }
        });
    }
    
    try {
        allEmployees = await fetchEmployees();
        populateDepartmentFilter(allEmployees);
        applyFilters();
    } catch (error) {
        showToast(error.message || 'Cannot connect to Spring Boot backend.', 'error');
        allEmployees = [];
        applyFilters();
    }
}

function populateDepartmentFilter(employees) {
    const departmentFilter = document.getElementById('departmentFilter');
    if (!departmentFilter) return;
    
    const depts = new Set(employees.map(e => e.department));
    
    departmentFilter.innerHTML = '<option value="">All Departments</option>';
    depts.forEach(d => {
        const opt = document.createElement('option');
        opt.value = d;
        opt.textContent = d;
        departmentFilter.appendChild(opt);
    });
}

function getFilteredEmployees() {
    let result = [...allEmployees];
    
    const searchInput = document.getElementById('searchInput');
    const departmentFilter = document.getElementById('departmentFilter');
    const salarySort = document.getElementById('salarySort');
    
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const dept = departmentFilter ? departmentFilter.value : '';
    const sort = salarySort ? salarySort.value : '';
    
    if (query) {
        result = result.filter(e => 
            e.firstName.toLowerCase().includes(query) ||
            e.lastName.toLowerCase().includes(query) ||
            (e.firstName.toLowerCase() + ' ' + e.lastName.toLowerCase()).includes(query) ||
            e.email.toLowerCase().includes(query) ||
            e.department.toLowerCase().includes(query) ||
            (e.position && e.position.toLowerCase().includes(query))
        );
    }
    
    if (dept) {
        result = result.filter(e => e.department === dept);
    }
    
    if (sort === 'low-high') {
        result.sort((a, b) => a.salary - b.salary);
    } else if (sort === 'high-low') {
        result.sort((a, b) => b.salary - a.salary);
    }
    
    return result;
}

function applyFilters() {
    filteredEmployees = getFilteredEmployees();
    currentPage = 1;
    renderEmployeeTable(filteredEmployees);
    renderPagination(filteredEmployees.length);
    
    const employeeCount = document.getElementById('employeeCount');
    if (employeeCount) {
        employeeCount.textContent = `Showing ${filteredEmployees.length} employees`;
    }
}

function renderEmployeeTable(employees) {
    const employeeTableBody = document.getElementById('employeeTableBody');
    if (!employeeTableBody) return;
    
    const start = (currentPage - 1) * PAGE_SIZE;
    const pageEmployees = employees.slice(start, start + PAGE_SIZE);
    
    employeeTableBody.innerHTML = '';
    
    if (employees.length === 0) {
        employeeTableBody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align:center; padding:48px 24px;">
                    <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; gap:12px; color:var(--muted);">
                        <i data-lucide="inbox" style="width:40px; height:40px;"></i>
                        <div style="font-weight:600; font-size:16px; color:var(--text);">No Employees Found</div>
                        <div style="font-size:14px;">Try adjusting your search filters or click "Add Employee" to create one.</div>
                    </div>
                </td>
            </tr>
        `;
        if (typeof lucide !== 'undefined') lucide.createIcons();
        return;
    }
    
    pageEmployees.forEach(emp => {
        const tr = document.createElement('tr');
        const color = getAvatarColor(emp.firstName + ' ' + emp.lastName);
        const initials = getInitials(emp.firstName, emp.lastName);
        const positionText = emp.position && emp.position.trim() ? emp.position : 'Team Member';
        
        tr.innerHTML = `
            <td>
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width:40px;height:40px;border-radius:50%;background:${color};color:white;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:14px;flex-shrink:0;">
                        ${initials}
                    </div>
                    <div>
                        <div style="font-weight: 600; color: var(--text); font-size: 0.9rem;">${emp.firstName} ${emp.lastName}</div>
                        <div style="font-size: 0.75rem; color: var(--primary); font-weight: 500; margin: 1px 0;">${positionText}</div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">${emp.email}</div>
                    </div>
                </div>
            </td>
            <td>
                <span class="badge" style="background: var(--accent-glow); color: var(--primary); font-weight: 600; font-size: 0.75rem; padding: 4px 10px;">
                    ${positionText}
                </span>
            </td>
            <td style="color: var(--text-secondary); font-size: 0.85rem;">${emp.phoneNumber || 'N/A'}</td>
            <td><span class="badge" style="background:var(--bg-secondary); color:var(--text); border:1px solid var(--border); padding:4px 10px; font-size:0.75rem; font-weight:500;">${emp.department}</span></td>
            <td class="salary-col" style="font-weight: 600;">${formatCurrency(emp.salary)}</td>
            <td class="actions-cell">
                <button class="btn-icon view-btn" data-id="${emp.id}" title="View Details">
                    <i data-lucide="eye"></i>
                </button>
                <button class="btn-icon edit-btn" data-id="${emp.id}" title="Edit Employee">
                    <i data-lucide="pencil"></i>
                </button>
                <button class="btn-icon delete-btn" data-id="${emp.id}" title="Delete Employee" style="color: var(--danger);">
                    <i data-lucide="trash-2"></i>
                </button>
            </td>
        `;
        employeeTableBody.appendChild(tr);
    });
    
    // Attach event listeners
    employeeTableBody.querySelectorAll('.view-btn').forEach(btn => {
        btn.addEventListener('click', (e) => openViewModal(parseInt(e.currentTarget.getAttribute('data-id'))));
    });
    employeeTableBody.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', (e) => openEditModal(parseInt(e.currentTarget.getAttribute('data-id'))));
    });
    employeeTableBody.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = parseInt(e.currentTarget.getAttribute('data-id'));
            const emp = allEmployees.find(x => x.id === id);
            openDeleteModal(id, emp ? `${emp.firstName} ${emp.lastName}` : 'this employee');
        });
    });
    
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

function renderPagination(totalItems) {
    const pagination = document.getElementById('pagination');
    if (!pagination) return;
    
    pagination.innerHTML = '';
    const totalPages = Math.ceil(totalItems / PAGE_SIZE);
    
    if (totalPages <= 1) return;
    
    // Prev Button
    const prevBtn = document.createElement('button');
    prevBtn.className = 'btn btn-outline';
    prevBtn.innerHTML = '<i data-lucide="chevron-left"></i> Prev';
    prevBtn.disabled = currentPage === 1;
    prevBtn.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            renderEmployeeTable(filteredEmployees);
            renderPagination(totalItems);
        }
    });
    pagination.appendChild(prevBtn);
    
    // Page Numbers
    const pageContainer = document.createElement('div');
    pageContainer.style.display = 'flex';
    pageContainer.style.gap = '4px';
    
    for (let i = 1; i <= totalPages; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = `btn btn-outline ${i === currentPage ? 'active' : ''}`;
        pageBtn.style.minWidth = '36px';
        pageBtn.style.padding = '8px';
        if(i === currentPage) {
            pageBtn.style.background = 'var(--primary)';
            pageBtn.style.color = 'white';
            pageBtn.style.borderColor = 'var(--primary)';
        }
        pageBtn.textContent = i;
        pageBtn.addEventListener('click', () => {
            currentPage = i;
            renderEmployeeTable(filteredEmployees);
            renderPagination(totalItems);
        });
        pageContainer.appendChild(pageBtn);
    }
    
    pagination.appendChild(pageContainer);
    
    // Next Button
    const nextBtn = document.createElement('button');
    nextBtn.className = 'btn btn-outline';
    nextBtn.innerHTML = 'Next <i data-lucide="chevron-right"></i>';
    nextBtn.disabled = currentPage === totalPages;
    nextBtn.addEventListener('click', () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderEmployeeTable(filteredEmployees);
            renderPagination(totalItems);
        }
    });
    pagination.appendChild(nextBtn);
    
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

// === CRUD MODAL FUNCTIONS ===

function openAddModal() {
    editingId = null;
    document.getElementById('employeeModalTitle').textContent = 'Add New Employee';
    document.getElementById('employeeModalSubtitle').textContent = 'Enter employee information below.';
    document.getElementById('employeeForm').reset();
    document.getElementById('saveEmployeeBtn').textContent = 'Add Employee';
    
    // clear errors
    document.querySelectorAll('#employeeForm .error-message').forEach(el => el.remove());
    document.querySelectorAll('#employeeForm .error').forEach(el => el.classList.remove('error'));
    
    document.getElementById('employeeModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function openEditModal(id) {
    const emp = allEmployees.find(e => e.id === id);
    if (!emp) return;
    
    editingId = id;
    document.getElementById('employeeModalTitle').textContent = 'Edit Employee';
    document.getElementById('employeeModalSubtitle').textContent = 'Update employee information.';
    
    document.getElementById('empFirstName').value = emp.firstName;
    document.getElementById('empLastName').value = emp.lastName;
    document.getElementById('empEmail').value = emp.email;
    const empPositionEl = document.getElementById('empPosition');
    if (empPositionEl) empPositionEl.value = emp.position || '';
    document.getElementById('empPhone').value = emp.phoneNumber || '';
    document.getElementById('empDepartment').value = emp.department;
    document.getElementById('empSalary').value = emp.salary;
    
    document.getElementById('saveEmployeeBtn').textContent = 'Save Changes';
    
    // clear errors
    document.querySelectorAll('#employeeForm .error-message').forEach(el => el.remove());
    document.querySelectorAll('#employeeForm .error').forEach(el => el.classList.remove('error'));
    
    document.getElementById('employeeModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

async function handleSaveEmployee(e) {
    e.preventDefault();
    
    const firstName = document.getElementById('empFirstName').value.trim();
    const lastName = document.getElementById('empLastName').value.trim();
    const email = document.getElementById('empEmail').value.trim();
    const empPositionEl = document.getElementById('empPosition');
    const position = empPositionEl ? empPositionEl.value.trim() : '';
    const phoneNumber = document.getElementById('empPhone').value.trim();
    const department = document.getElementById('empDepartment').value.trim();
    const salary = parseFloat(document.getElementById('empSalary').value);
    
    // Validation
    let isValid = true;
    document.querySelectorAll('#employeeForm .error-message').forEach(el => el.remove());
    document.querySelectorAll('#employeeForm .error').forEach(el => el.classList.remove('error'));
    
    if (!firstName) { showInlineError(document.getElementById('empFirstName'), 'First Name is required'); isValid = false; }
    if (!lastName) { showInlineError(document.getElementById('empLastName'), 'Last Name is required'); isValid = false; }
    if (!email) { showInlineError(document.getElementById('empEmail'), 'Email is required'); isValid = false; }
    else if (!/^\S+@\S+\.\S+$/.test(email)) { showInlineError(document.getElementById('empEmail'), 'Invalid email format'); isValid = false; }
    if (!department) { showInlineError(document.getElementById('empDepartment'), 'Department is required'); isValid = false; }
    if (isNaN(salary) || salary <= 0) { showInlineError(document.getElementById('empSalary'), 'Valid Salary is required'); isValid = false; }
    
    if (!isValid) return;
    
    const data = { firstName, lastName, email, phoneNumber, department, position, salary };
    const btn = document.getElementById('saveEmployeeBtn');
    const originalText = btn.textContent;
    btn.textContent = 'Saving...';
    btn.disabled = true;
    
    try {
        if (editingId) {
            await updateEmployee(editingId, data);
            showToast('Employee updated successfully', 'success');
        } else {
            await createEmployee(data);
            showToast('Employee added successfully', 'success');
        }
        
        closeModal('employeeModal');
        allEmployees = await fetchEmployees();
        populateDepartmentFilter(allEmployees);
        applyFilters();
    } catch (err) {
        showToast(err.message || 'Operation failed', 'error');
    } finally {
        btn.textContent = originalText;
        btn.disabled = false;
    }
}

function openViewModal(id) {
    const emp = allEmployees.find(e => e.id === id);
    if (!emp) return;
    
    const viewContent = document.getElementById('viewContent');
    const color = getAvatarColor(emp.firstName + ' ' + emp.lastName);
    const initials = getInitials(emp.firstName, emp.lastName);
    
    viewContent.innerHTML = `
        <div style="text-align: center; margin-bottom: 24px;">
            <div style="width:80px;height:80px;border-radius:50%;background:${color};color:white;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:28px;margin: 0 auto 16px;">
                ${initials}
            </div>
            <h3 style="font-size: 20px; font-weight: 600; color: var(--text); margin-bottom: 4px;">${emp.firstName} ${emp.lastName}</h3>
            <p style="color: var(--muted);">${emp.position ? emp.position + ' • ' : ''}${emp.department}</p>
        </div>
        <div style="display: flex; flex-direction: column; gap: 16px;">
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--bg); border-radius: 8px;">
                <i data-lucide="hash" style="color: var(--muted); width: 20px; height: 20px;"></i>
                <div>
                    <div style="font-size: 12px; color: var(--muted);">Employee ID</div>
                    <div style="font-weight: 500; color: var(--text);">${emp.id}</div>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--bg); border-radius: 8px;">
                <i data-lucide="briefcase" style="color: var(--muted); width: 20px; height: 20px;"></i>
                <div>
                    <div style="font-size: 12px; color: var(--muted);">Job Title / Position</div>
                    <div style="font-weight: 500; color: var(--text);">${emp.position || 'N/A'}</div>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--bg); border-radius: 8px;">
                <i data-lucide="mail" style="color: var(--muted); width: 20px; height: 20px;"></i>
                <div>
                    <div style="font-size: 12px; color: var(--muted);">Email Address</div>
                    <div style="font-weight: 500; color: var(--text);">${emp.email}</div>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--bg); border-radius: 8px;">
                <i data-lucide="phone" style="color: var(--muted); width: 20px; height: 20px;"></i>
                <div>
                    <div style="font-size: 12px; color: var(--muted);">Phone Number</div>
                    <div style="font-weight: 500; color: var(--text);">${emp.phoneNumber || 'N/A'}</div>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--bg); border-radius: 8px;">
                <i data-lucide="building-2" style="color: var(--muted); width: 20px; height: 20px;"></i>
                <div>
                    <div style="font-size: 12px; color: var(--muted);">Department</div>
                    <div style="font-weight: 500; color: var(--text);">${emp.department}</div>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--bg); border-radius: 8px;">
                <i data-lucide="dollar-sign" style="color: var(--muted); width: 20px; height: 20px;"></i>
                <div>
                    <div style="font-size: 12px; color: var(--muted);">Salary</div>
                    <div style="font-weight: 500; color: var(--text);">${formatCurrency(emp.salary)}</div>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('viewModal').classList.add('active');
    document.body.style.overflow = 'hidden';
    
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

function openDeleteModal(id, name) {
    document.getElementById('deleteEmployeeName').textContent = name;
    window._deleteId = id;
    document.getElementById('deleteModal').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
    document.body.style.overflow = '';
    
    if (modalId === 'employeeModal') {
        const form = document.getElementById('employeeForm');
        if(form) form.reset();
        document.querySelectorAll(`#${modalId} .error-message`).forEach(el => el.remove());
        document.querySelectorAll(`#${modalId} .error`).forEach(el => el.classList.remove('error'));
    }
}

// === DEPARTMENTS PAGE ===

async function initDepartments() {
    const deptGrid = document.getElementById('deptGrid');
    if (deptGrid) showSkeleton(deptGrid, 'cards');
    
    try {
        allEmployees = await fetchEmployees();
        renderDepartments(allEmployees);
    } catch (error) {
        if (deptGrid) showErrorState(deptGrid, error.message, initDepartments);
    }
}

function renderDepartments(employees) {
    const stats = calculateDeptStats(employees);
    
    // Render KPIs
    const deptKpiTotal = document.getElementById('deptKpiTotal');
    const deptKpiLargest = document.getElementById('deptKpiLargest');
    const deptKpiAvg = document.getElementById('deptKpiAvg');
    const deptKpiHighest = document.getElementById('deptKpiHighest');
    
    if (deptKpiTotal) deptKpiTotal.textContent = stats.departments.length;
    
    let largestDept = null;
    let highestSalaryDept = null;
    let totalEmployees = 0;
    
    stats.departments.forEach(d => {
        totalEmployees += d.count;
        if (!largestDept || d.count > largestDept.count) largestDept = d;
        if (!highestSalaryDept || d.avgSalary > highestSalaryDept.avgSalary) highestSalaryDept = d;
    });
    
    if (deptKpiLargest) deptKpiLargest.textContent = largestDept ? largestDept.name : 'N/A';
    if (deptKpiAvg) deptKpiAvg.textContent = stats.departments.length > 0 ? (totalEmployees / stats.departments.length).toFixed(1) : '0';
    if (deptKpiHighest) deptKpiHighest.textContent = highestSalaryDept ? highestSalaryDept.name : 'N/A';
    
    // Render Grid
    const deptGrid = document.getElementById('deptGrid');
    if (deptGrid) {
        deptGrid.innerHTML = '';
        stats.departments.forEach(d => {
            const card = document.createElement('div');
            card.className = 'dept-card';
            card.style.background = 'var(--surface)';
            card.style.borderRadius = '12px';
            card.style.padding = '24px';
            card.style.boxShadow = 'var(--shadow)';
            card.style.border = '1px solid var(--border)';
            
            card.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px;">
                    <h3 style="font-size: 18px; font-weight: 600; color: var(--text); margin: 0;">${d.name}</h3>
                    <span style="background: var(--primary); color: white; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: 500;">
                        ${d.count} Employees
                    </span>
                </div>
                <div style="display: flex; flex-direction: column; gap: 12px;">
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: var(--muted); font-size: 14px;">Avg Salary</span>
                        <span style="font-weight: 500;">${formatCurrency(d.avgSalary)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: var(--muted); font-size: 14px;">Min Salary</span>
                        <span style="font-weight: 500;">${formatCurrency(d.minSalary)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: var(--muted); font-size: 14px;">Max Salary</span>
                        <span style="font-weight: 500;">${formatCurrency(d.maxSalary)}</span>
                    </div>
                </div>
            `;
            deptGrid.appendChild(card);
        });
    }
    
    // Render Charts
    const distCanvas = document.getElementById('deptDistChart');
    const salCanvas = document.getElementById('deptSalaryChart');
    
    if (distCanvas && salCanvas) {
        if (chartInstances.deptDistChart) chartInstances.deptDistChart.destroy();
        if (chartInstances.deptSalaryChart) chartInstances.deptSalaryChart.destroy();
        
        const labels = stats.departments.map(d => d.name);
        const counts = stats.departments.map(d => d.count);
        const avgs = stats.departments.map(d => d.avgSalary);
        
        chartInstances.deptDistChart = new Chart(distCanvas, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Employees',
                    data: counts,
                    backgroundColor: '#8b5cf6',
                    borderRadius: 6
                }]
            },
            options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false }
        });
        
        chartInstances.deptSalaryChart = new Chart(salCanvas, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Avg Salary',
                    data: avgs,
                    backgroundColor: '#10b981',
                    borderRadius: 6
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }
    
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

function calculateDeptStats(employees) {
    const map = {};
    employees.forEach(e => {
        const d = e.department || 'Unassigned';
        if (!map[d]) {
            map[d] = { name: d, count: 0, totalSalary: 0, minSalary: e.salary, maxSalary: e.salary };
        }
        map[d].count++;
        map[d].totalSalary += e.salary;
        if (e.salary < map[d].minSalary) map[d].minSalary = e.salary;
        if (e.salary > map[d].maxSalary) map[d].maxSalary = e.salary;
    });
    
    const depts = Object.values(map).map(d => ({
        ...d,
        avgSalary: d.totalSalary / d.count
    }));
    
    return { departments: depts };
}

// === SALARY PAGE ===

async function initSalary() {
    try {
        allEmployees = await fetchEmployees();
        renderSalaryAnalytics(allEmployees);
    } catch (error) {
        showToast(error.message || 'Cannot connect to Spring Boot backend.', 'error');
        renderSalaryAnalytics([]);
    }
}

function renderSalaryAnalytics(employees) {
    const tableBody = document.getElementById('salaryRankingBody');
    
    if (employees.length === 0) {
        if (tableBody) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align:center; padding:32px; color:var(--muted);">
                        No employee salary data available
                    </td>
                </tr>
            `;
        }
        return;
    }
    
    let totalPayroll = 0;
    let highest = employees[0];
    let lowest = employees[0];
    
    employees.forEach(e => {
        totalPayroll += e.salary;
        if (e.salary > highest.salary) highest = e;
        if (e.salary < lowest.salary) lowest = e;
    });
    
    const avgSalary = totalPayroll / employees.length;
    
    const kpiTotal = document.getElementById('salaryKpiTotal');
    const kpiAvg = document.getElementById('salaryKpiAvg');
    const kpiHighest = document.getElementById('salaryKpiHighest');
    const kpiLowest = document.getElementById('salaryKpiLowest');
    
    if (kpiTotal) kpiTotal.textContent = formatCurrency(totalPayroll);
    if (kpiAvg) kpiAvg.textContent = formatCurrency(avgSalary);
    if (kpiHighest) kpiHighest.textContent = `${formatCurrency(highest.salary)} (${highest.firstName})`;
    if (kpiLowest) kpiLowest.textContent = `${formatCurrency(lowest.salary)} (${lowest.firstName})`;
    
    // Charts
    const byDeptCanvas = document.getElementById('salaryByDeptChart');
    const distCanvas = document.getElementById('salaryDistChart');
    
    if (byDeptCanvas && distCanvas) {
        if (chartInstances.salaryByDeptChart) chartInstances.salaryByDeptChart.destroy();
        if (chartInstances.salaryDistChart) chartInstances.salaryDistChart.destroy();
        
        const stats = calculateDeptStats(employees);
        const deptLabels = stats.departments.map(d => d.name);
        const deptAvgs = stats.departments.map(d => d.avgSalary);
        
        chartInstances.salaryByDeptChart = new Chart(byDeptCanvas, {
            type: 'bar',
            data: {
                labels: deptLabels,
                datasets: [{
                    label: 'Avg Salary',
                    data: deptAvgs,
                    backgroundColor: '#f59e0b',
                    borderRadius: 6
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
        
        // Distribution logic
        const ranges = {
            '0-30k': 0,
            '30k-50k': 0,
            '50k-70k': 0,
            '70k-100k': 0,
            '100k+': 0
        };
        
        employees.forEach(e => {
            if (e.salary < 30000) ranges['0-30k']++;
            else if (e.salary < 50000) ranges['30k-50k']++;
            else if (e.salary < 70000) ranges['50k-70k']++;
            else if (e.salary < 100000) ranges['70k-100k']++;
            else ranges['100k+']++;
        });
        
        chartInstances.salaryDistChart = new Chart(distCanvas, {
            type: 'bar',
            data: {
                labels: Object.keys(ranges),
                datasets: [{
                    label: 'Employees',
                    data: Object.values(ranges),
                    backgroundColor: '#06b6d4',
                    borderRadius: 6
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }
    
    // Table
    if (tableBody) {
        tableBody.innerHTML = '';
        const sorted = [...employees].sort((a, b) => b.salary - a.salary);
        const maxSal = sorted[0]?.salary || 1;
        
        sorted.forEach((emp, index) => {
            const tr = document.createElement('tr');
            const color = getAvatarColor(emp.firstName + ' ' + emp.lastName);
            const initials = getInitials(emp.firstName, emp.lastName);
            const pct = Math.round((emp.salary / maxSal) * 100);
            
            tr.innerHTML = `
                <td style="font-weight:600; color:var(--muted)">#${index + 1}</td>
                <td>
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <div style="width:32px;height:32px;border-radius:50%;background:${color};color:white;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:12px;">
                            ${initials}
                        </div>
                        <div>
                            <div style="font-weight: 500; color: var(--text);">${emp.firstName} ${emp.lastName}</div>
                        </div>
                    </div>
                </td>
                <td><span class="badge" style="background:var(--bg); border:1px solid var(--border); padding:4px 8px; border-radius:12px; font-size:12px;">${emp.department}</span></td>
                <td style="font-weight: 500;">${formatCurrency(emp.salary)}</td>
                <td>
                    <div style="display:flex; align-items:center; gap:8px;">
                        <div style="flex:1; height:8px; background:var(--bg); border-radius:4px; overflow:hidden;">
                            <div style="height:100%; width:${pct}%; background:var(--primary); border-radius:4px;"></div>
                        </div>
                        <span style="font-size:12px; color:var(--muted); width:30px;">${pct}%</span>
                    </div>
                </td>
            `;
            tableBody.appendChild(tr);
        });
    }
    
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

// === SETTINGS PAGE ===

async function initSettings() {
    const currentTheme = localStorage.getItem('ems_theme') || 'light';
    
    document.querySelectorAll('.theme-option').forEach(opt => {
        if (opt.getAttribute('data-value') === currentTheme) {
            opt.classList.add('active');
        }
        
        opt.addEventListener('click', function() {
            document.querySelectorAll('.theme-option').forEach(o => o.classList.remove('active'));
            this.classList.add('active');
            setTheme(this.getAttribute('data-value'));
        });
    });
    
    const apiStatus = document.getElementById('apiStatus');
    const apiStatusText = document.getElementById('apiStatusText');
    const apiUrl = document.getElementById('apiUrl');
    
    if (apiUrl) apiUrl.textContent = API_BASE;
    
    try {
        const response = await fetch(API_BASE);
        if (response.ok) {
            if (apiStatus) {
                apiStatus.style.background = 'var(--success, #10b981)';
                apiStatus.style.boxShadow = '0 0 0 4px rgba(16, 185, 129, 0.2)';
            }
            if (apiStatusText) apiStatusText.textContent = 'Online & Connected';
        } else {
            throw new Error('API returning non-200');
        }
    } catch (e) {
        if (apiStatus) {
            apiStatus.style.background = 'var(--danger, #ef4444)';
            apiStatus.style.boxShadow = '0 0 0 4px rgba(239, 68, 68, 0.2)';
        }
        if (apiStatusText) apiStatusText.textContent = 'Offline (Connection Failed)';
    }
}

// === TOAST NOTIFICATIONS ===

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let iconName = 'check-circle-2';
    if (type === 'error') iconName = 'x-circle';
    if (type === 'warning') iconName = 'alert-triangle';
    
    toast.innerHTML = `
        <div style="display:flex; align-items:center; gap:12px; padding:16px; background:var(--surface); border-radius:8px; box-shadow:0 10px 15px -3px rgba(0,0,0,0.1); border-left:4px solid ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#f59e0b'}; margin-bottom:12px; min-width:300px;">
            <i data-lucide="${iconName}" style="color:${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#f59e0b'};"></i>
            <span style="flex:1; font-weight:500; font-size:14px; color:var(--text);">${message}</span>
            <button class="btn-icon" onclick="this.parentElement.parentElement.remove()" style="padding:4px; margin:-8px;">
                <i data-lucide="x" style="width:16px; height:16px;"></i>
            </button>
        </div>
    `;
    
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.4s ease';
    
    container.appendChild(toast);
    if (typeof lucide !== 'undefined') lucide.createIcons();
    
    setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(0)';
        toast.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        toast.classList.remove('show');
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 400);
    }, 4000);
}

// === SKELETON LOADERS ===

function showSkeleton(container, type = 'table') {
    if (!container) return;
    container.innerHTML = '';
    
    if (type === 'table') {
        let html = '<div style="background:var(--surface); border-radius:12px; box-shadow:var(--shadow); overflow:hidden;">';
        for(let i=0; i<5; i++) {
            html += `
                <div style="display:flex; align-items:center; padding:16px 24px; border-bottom:1px solid var(--border); gap:24px;">
                    <div style="width:40px; height:40px; border-radius:50%; background:var(--border); animation:pulse 1.5s infinite;"></div>
                    <div style="flex:1;">
                        <div style="height:16px; width:120px; background:var(--border); border-radius:4px; margin-bottom:8px; animation:pulse 1.5s infinite;"></div>
                        <div style="height:12px; width:160px; background:var(--border); border-radius:4px; animation:pulse 1.5s infinite;"></div>
                    </div>
                    <div style="width:100px; height:24px; background:var(--border); border-radius:12px; animation:pulse 1.5s infinite;"></div>
                    <div style="width:80px; height:16px; background:var(--border); border-radius:4px; animation:pulse 1.5s infinite;"></div>
                </div>
            `;
        }
        html += '</div>';
        container.innerHTML = html;
    } else if (type === 'cards') {
        let html = '';
        for(let i=0; i<4; i++) {
            html += `
                <div style="background:var(--surface); border-radius:12px; padding:24px; border:1px solid var(--border); height:160px; animation:pulse 1.5s infinite;">
                    <div style="height:20px; width:60%; background:var(--border); border-radius:4px; margin-bottom:24px;"></div>
                    <div style="height:14px; width:40%; background:var(--border); border-radius:4px; margin-bottom:12px;"></div>
                    <div style="height:14px; width:80%; background:var(--border); border-radius:4px;"></div>
                </div>
            `;
        }
        container.innerHTML = html;
    } else if (type === 'dashboard') {
        container.innerHTML = `
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); gap:24px; margin-bottom:24px;">
                ${Array(4).fill('<div style="background:var(--surface); height:120px; border-radius:12px; border:1px solid var(--border); animation:pulse 1.5s infinite;"></div>').join('')}
            </div>
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(400px, 1fr)); gap:24px;">
                <div style="background:var(--surface); height:300px; border-radius:12px; border:1px solid var(--border); animation:pulse 1.5s infinite;"></div>
                <div style="background:var(--surface); height:300px; border-radius:12px; border:1px solid var(--border); animation:pulse 1.5s infinite;"></div>
            </div>
        `;
    }
}

// === ERROR/EMPTY STATES ===

function showErrorState(container, message, retryFn) {
    if (!container) return;
    container.innerHTML = `
        <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; padding:64px 24px; text-align:center; background:var(--surface); border-radius:12px; border:1px dashed var(--border);">
            <div style="width:64px; height:64px; border-radius:50%; background:rgba(239, 68, 68, 0.1); color:var(--danger, #ef4444); display:flex; align-items:center; justify-content:center; margin-bottom:24px;">
                <i data-lucide="wifi-off" style="width:32px; height:32px;"></i>
            </div>
            <h3 style="font-size:20px; font-weight:600; color:var(--text); margin-bottom:8px;">Connection Error</h3>
            <p style="color:var(--muted); max-width:400px; margin-bottom:24px;">${message}</p>
            <button class="btn btn-primary" id="retryBtn">
                <i data-lucide="refresh-cw"></i> Try Again
            </button>
        </div>
    `;
    
    document.getElementById('retryBtn').addEventListener('click', retryFn);
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

function showEmptyState(container, message = 'No employees found') {
    if (!container) return;
    container.innerHTML = `
        <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; padding:64px 24px; text-align:center; background:var(--surface); border-radius:12px; border:1px dashed var(--border);">
            <div style="width:64px; height:64px; border-radius:50%; background:var(--bg); color:var(--muted); display:flex; align-items:center; justify-content:center; margin-bottom:24px;">
                <i data-lucide="inbox" style="width:32px; height:32px;"></i>
            </div>
            <h3 style="font-size:20px; font-weight:600; color:var(--text); margin-bottom:8px;">No Data Available</h3>
            <p style="color:var(--muted); max-width:400px; margin-bottom:24px;">${message}</p>
        </div>
    `;
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

// === THEME ===

function loadTheme() {
    const theme = localStorage.getItem('ems_theme') || 'light';
    document.body.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
}

function toggleTheme() {
    const current = document.body.getAttribute('data-theme');
    const newTheme = current === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
}

function setTheme(theme) {
    document.body.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('ems_theme', theme);
    
    // Update theme toggle icon if it exists
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        const icon = themeToggle.querySelector('i');
        if (icon) {
            icon.setAttribute('data-lucide', theme === 'dark' ? 'sun' : 'moon');
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    }
}

// === SIDEBAR ===

function setupSidebar() {
    const menuToggle = document.getElementById('menuToggle');
    const sidebarClose = document.getElementById('sidebarClose');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const sidebar = document.getElementById('sidebar');
    
    if (menuToggle && sidebar && sidebarOverlay) {
        menuToggle.addEventListener('click', () => {
            sidebar.classList.add('active');
            sidebarOverlay.classList.add('active');
        });
    }
    
    if (sidebarClose) {
        sidebarClose.addEventListener('click', closeSidebar);
    }
    
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', closeSidebar);
    }
}

function closeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    if (sidebar) sidebar.classList.remove('active');
    if (sidebarOverlay) sidebarOverlay.classList.remove('active');
}

// === NOTIFICATIONS ===

function setupNotifications() {
    const notifBtn = document.querySelector('.notification-btn');
    if (!notifBtn) return;
    
    // Create dropdown container dynamically if not present
    let dropdown = document.getElementById('notificationDropdown');
    if (!dropdown) {
        dropdown = document.createElement('div');
        dropdown.id = 'notificationDropdown';
        dropdown.className = 'notification-dropdown';
        dropdown.innerHTML = `
            <div class="notif-header">
                <h4>Notifications</h4>
                <button class="notif-clear-btn" id="clearNotifsBtn">Mark all as read</button>
            </div>
            <div class="notif-list" id="notifList">
                <div class="notif-item unread">
                    <div class="notif-icon green"><i data-lucide="user-plus" style="width:16px;height:16px;"></i></div>
                    <div class="notif-content">
                        <div class="notif-title">New Employee Registered</div>
                        <div class="notif-desc">Sarah Connor joined IT Department</div>
                        <div class="notif-time">10 minutes ago</div>
                    </div>
                </div>
                <div class="notif-item unread">
                    <div class="notif-icon blue"><i data-lucide="building-2" style="width:16px;height:16px;"></i></div>
                    <div class="notif-content">
                        <div class="notif-title">Department Budget Revised</div>
                        <div class="notif-desc">Engineering Q3 salary pool updated</div>
                        <div class="notif-time">1 hour ago</div>
                    </div>
                </div>
                <div class="notif-item unread">
                    <div class="notif-icon purple"><i data-lucide="wallet" style="width:16px;height:16px;"></i></div>
                    <div class="notif-content">
                        <div class="notif-title">Monthly Payroll Generated</div>
                        <div class="notif-desc">Payroll summary ready for export</div>
                        <div class="notif-time">2 hours ago</div>
                    </div>
                </div>
            </div>
        `;
        notifBtn.style.position = 'relative';
        notifBtn.appendChild(dropdown);
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }
    
    notifBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('show');
    });
    
    document.addEventListener('click', (e) => {
        if (dropdown && !dropdown.contains(e.target) && !notifBtn.contains(e.target)) {
            dropdown.classList.remove('show');
        }
    });
    
    const clearBtn = document.getElementById('clearNotifsBtn');
    if (clearBtn) {
        clearBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const badge = notifBtn.querySelector('.notification-badge');
            if (badge) badge.style.display = 'none';
            document.querySelectorAll('.notif-item').forEach(item => item.classList.remove('unread'));
            showToast('All notifications marked as read', 'success');
        });
    }
}

// === UTILITY FUNCTIONS ===

function formatCurrency(amount) {
    return '$' + Number(amount).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function getInitials(firstName, lastName) {
    const f = firstName?.charAt(0) || '';
    const l = lastName?.charAt(0) || '';
    return (f + l).toUpperCase();
}

function getAvatarColor(name) {
    const colors = ['#3b82f6','#8b5cf6','#06b6d4','#10b981','#f59e0b','#ef4444','#ec4899','#6366f1','#14b8a6','#f97316'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
        hash += name.charCodeAt(i);
    }
    return colors[hash % colors.length];
}

function getGreeting() {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
}

function debounce(fn, delay = 300) {
    let timeoutId;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => fn.apply(this, args), delay);
    };
}

// CSS Animation injection for skeletons (fallback if not in CSS)
const style = document.createElement('style');
style.innerHTML = `
@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: .5; }
}
`;
document.head.appendChild(style);
