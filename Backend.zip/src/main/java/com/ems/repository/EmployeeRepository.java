package com.ems.repository;

import com.ems.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Search by Department
    List<Employee> findByDepartmentIgnoreCase(String department);

    // Search by First Name
    List<Employee> findByFirstNameContainingIgnoreCase(String firstName);

    // Search by Email
    Optional<Employee> findByEmailIgnoreCase(String email);
}